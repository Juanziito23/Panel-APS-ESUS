import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { LoginForm } from '../components/LoginForm';
import { loginAdmin } from '../services/auth';
import { useAuthStore } from '../stores/authStore';
import type { AdminCredentials } from '../types/auth';

export function AdminLogin() {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string>();
  const navigate = useNavigate();
  const setAuth = useAuthStore((state) => state.setAuth);

  const handleSubmit = async (credentials: AdminCredentials) => {
    try {
      setIsLoading(true);
      setError(undefined);
      const response = await loginAdmin(credentials);
      setAuth(response.token, response.user);
      navigate('/admin');
    } catch (err) {
      setError('Credenciais inválidas. Por favor, tente novamente.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <LoginForm
      onSubmit={handleSubmit}
      isLoading={isLoading}
      error={error}
      title="Login Administrativo"
      subtitle="Acesse o painel de administração"
    />
  );
}