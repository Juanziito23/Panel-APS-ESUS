import React from 'react';
import { ConfigForm } from '../components/ConfigForm';

export function AdminConfig() {
  return (
    <div className="space-y-6">
      <div className="bg-white px-4 py-5 shadow sm:rounded-lg sm:p-6">
        <div className="md:grid md:grid-cols-3 md:gap-6">
          <div className="md:col-span-1">
            <h3 className="text-lg font-medium leading-6 text-gray-900">Configurações do Sistema</h3>
            <p className="mt-1 text-sm text-gray-500">
              Configure os parâmetros de conexão com o banco de dados PostgreSQL.
            </p>
          </div>
          <div className="mt-5 md:col-span-2 md:mt-0">
            <ConfigForm />
          </div>
        </div>
      </div>
    </div>
  );
}