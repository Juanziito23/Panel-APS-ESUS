export interface AdminCredentials {
  username: string;
  password: string;
}

export interface UserCredentials {
  username: string;
  password: string;
}

export interface AuthResponse {
  token: string;
  user: {
    id: string;
    name: string;
    role: 'admin' | 'user';
  };
}