import axios from 'axios';
import type { AdminCredentials, UserCredentials, AuthResponse } from '../types/auth';

export async function loginAdmin(credentials: AdminCredentials): Promise<AuthResponse> {
  const response = await axios.post<AuthResponse>('/api/auth/admin/login', credentials);
  return response.data;
}

export async function loginUser(credentials: UserCredentials): Promise<AuthResponse> {
  const response = await axios.post<AuthResponse>('/api/auth/login', credentials);
  return response.data;
}