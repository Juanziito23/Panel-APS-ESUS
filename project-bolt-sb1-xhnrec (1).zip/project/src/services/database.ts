import axios, { AxiosError } from 'axios';
import type { DatabaseConfig } from '../types/config';

interface DatabaseError {
  code: string;
  message: string;
}

function getErrorMessage(error: unknown): string {
  if (error instanceof AxiosError) {
    const dbError = error.response?.data as DatabaseError | undefined;
    
    switch (dbError?.code) {
      case 'ECONNREFUSED':
        return 'Não foi possível conectar ao servidor. Verifique se o host e porta estão corretos.';
      case '28P01':
        return 'Credenciais inválidas. Verifique o usuário e senha.';
      case '3D000':
        return 'Banco de dados não existe.';
      case 'ETIMEDOUT':
        return 'Tempo de conexão esgotado. Verifique se o servidor está acessível.';
      default:
        if (error.message.includes('Network Error')) {
          return 'Erro de rede. Verifique sua conexão com a internet.';
        }
        return dbError?.message || 'Erro desconhecido ao tentar conectar ao banco de dados.';
    }
  }
  
  return 'Ocorreu um erro inesperado ao testar a conexão.';
}

export async function testConnection(config: DatabaseConfig): Promise<{ success: boolean; message: string }> {
  try {
    // Adiciona timeout de 10 segundos para a requisição
    const response = await axios.post('/api/test-connection', config, {
      timeout: 10000,
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (response.data?.connected) {
      return {
        success: true,
        message: 'Conexão estabelecida com sucesso! Banco de dados está respondendo corretamente.',
      };
    }

    return {
      success: false,
      message: 'Não foi possível estabelecer conexão com o banco de dados.',
    };
  } catch (error) {
    return {
      success: false,
      message: getErrorMessage(error),
    };
  }
}