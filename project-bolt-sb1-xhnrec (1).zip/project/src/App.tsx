import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AdminLayout } from './components/AdminLayout';
import { AdminConfig } from './pages/AdminConfig';
import { AdminLogin } from './pages/AdminLogin';
import { UserLogin } from './pages/UserLogin';
import { useAuthStore } from './stores/authStore';

function PrivateRoute({ children, requiredRole }: { children: React.ReactNode; requiredRole: 'admin' | 'user' }) {
  const user = useAuthStore((state) => state.user);
  
  if (!user) {
    return <Navigate to={requiredRole === 'admin' ? '/admin/login' : '/login'} replace />;
  }

  if (user.role !== requiredRole) {
    return <Navigate to="/" replace />;
  }

  return <>{children}</>;
}

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Navigate to="/login" replace />} />
        
        {/* Admin Routes */}
        <Route path="/admin/login" element={<AdminLogin />} />
        <Route
          path="/admin"
          element={
            <PrivateRoute requiredRole="admin">
              <AdminLayout />
            </PrivateRoute>
          }
        >
          <Route index element={<AdminConfig />} />
        </Route>

        {/* User Routes */}
        <Route path="/login" element={<UserLogin />} />
        <Route
          path="/dashboard"
          element={
            <PrivateRoute requiredRole="user">
              <div>Dashboard do Usuário (Em desenvolvimento)</div>
            </PrivateRoute>
          }
        />
      </Routes>
    </BrowserRouter>
  );
}

export default App;