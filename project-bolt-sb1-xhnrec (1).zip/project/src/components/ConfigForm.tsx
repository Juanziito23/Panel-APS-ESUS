import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Database, AlertCircle, CheckCircle2 } from 'lucide-react';
import { useConfigStore } from '../stores/configStore';
import { testConnection } from '../services/database';
import type { AppConfig } from '../types/config';

const configSchema = z.object({
  database: z.object({
    host: z.string().min(1, 'Host é obrigatório'),
    port: z.number().min(1, 'Porta é obrigatória'),
    database: z.string().min(1, 'Nome do banco é obrigatório'),
    username: z.string().min(1, 'Usuário é obrigatório'),
    password: z.string().min(1, 'Senha é obrigatória'),
  }),
});

export function ConfigForm() {
  const { config, setConfig } = useConfigStore();
  const [testStatus, setTestStatus] = useState<{ success?: boolean; message?: string }>({});
  const [isTestingConnection, setIsTestingConnection] = useState(false);
  
  const { register, handleSubmit, formState: { errors }, getValues } = useForm<AppConfig>({
    resolver: zodResolver(configSchema),
    defaultValues: config || undefined,
  });

  const onSubmit = (data: AppConfig) => {
    setConfig(data);
    alert('Configuração salva com sucesso!');
  };

  const handleTestConnection = async () => {
    try {
      const formData = getValues();
      
      // Validar se todos os campos necessários estão preenchidos
      if (!formData.database?.host || !formData.database?.port || 
          !formData.database?.database || !formData.database?.username || 
          !formData.database?.password) {
        setTestStatus({
          success: false,
          message: 'Preencha todos os campos antes de testar a conexão.',
        });
        return;
      }

      setIsTestingConnection(true);
      setTestStatus({});
      const result = await testConnection(formData.database);
      setTestStatus(result);
    } catch (error) {
      setTestStatus({
        success: false,
        message: 'Erro inesperado ao testar conexão. Tente novamente.',
      });
    } finally {
      setIsTestingConnection(false);
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6 bg-white p-6 rounded-lg shadow">
      <div className="space-y-4">
        <h2 className="text-xl font-semibold">Configuração do Banco de Dados</h2>
        
        <div>
          <label className="block text-sm font-medium text-gray-700">Host</label>
          <input
            {...register('database.host')}
            type="text"
            placeholder="Ex: localhost ou db.exemplo.com"
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
          />
          {errors.database?.host && (
            <p className="mt-1 text-sm text-red-600">{errors.database.host.message}</p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Porta</label>
          <input
            {...register('database.port', { valueAsNumber: true })}
            type="number"
            placeholder="Ex: 5432"
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
          />
          {errors.database?.port && (
            <p className="mt-1 text-sm text-red-600">{errors.database.port.message}</p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Nome do Banco</label>
          <input
            {...register('database.database')}
            type="text"
            placeholder="Ex: esus_db"
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
          />
          {errors.database?.database && (
            <p className="mt-1 text-sm text-red-600">{errors.database.database.message}</p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Usuário</label>
          <input
            {...register('database.username')}
            type="text"
            placeholder="Ex: postgres"
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
          />
          {errors.database?.username && (
            <p className="mt-1 text-sm text-red-600">{errors.database.username.message}</p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Senha</label>
          <input
            {...register('database.password')}
            type="password"
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
          />
          {errors.database?.password && (
            <p className="mt-1 text-sm text-red-600">{errors.database.password.message}</p>
          )}
        </div>

        {testStatus.message && (
          <div className={`p-4 rounded-md flex items-start space-x-3 ${
            testStatus.success ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'
          }`}>
            {testStatus.success ? (
              <CheckCircle2 className="h-5 w-5 mt-0.5" />
            ) : (
              <AlertCircle className="h-5 w-5 mt-0.5" />
            )}
            <span className="flex-1">{testStatus.message}</span>
          </div>
        )}
      </div>

      <div className="flex justify-between items-center">
        <button
          type="button"
          onClick={handleTestConnection}
          disabled={isTestingConnection}
          className={`inline-flex items-center px-4 py-2 border shadow-sm text-sm font-medium rounded-md ${
            isTestingConnection
              ? 'bg-gray-100 text-gray-500 cursor-not-allowed'
              : 'border-gray-300 text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500'
          }`}
        >
          <Database className="mr-2 h-4 w-4" />
          {isTestingConnection ? 'Testando...' : 'Testar Conexão'}
        </button>

        <button
          type="submit"
          className="inline-flex justify-center rounded-md border border-transparent bg-indigo-600 py-2 px-4 text-sm font-medium text-white shadow-sm hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
        >
          Salvar Configurações
        </button>
      </div>
    </form>
  );
}