import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { AppConfig } from '../types/config';

interface ConfigStore {
  config: AppConfig | null;
  setConfig: (config: AppConfig) => void;
}

export const useConfigStore = create<ConfigStore>()(
  persist(
    (set) => ({
      config: null,
      setConfig: (config) => set({ config }),
    }),
    {
      name: 'aps-esus-config',
    }
  )
);